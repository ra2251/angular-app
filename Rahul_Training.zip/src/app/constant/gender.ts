export enum Gender {
    male = 'man',
    female = 'woman'
  }