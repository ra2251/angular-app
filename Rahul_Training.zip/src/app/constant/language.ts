export enum Language{
    "English"="English",
    "Nederlands"="Nederlands",
    "Türkçe"="Türkçe",
    "عـــربـــي"="عـــربـــي"
}

// export const Language=[
//     {
//        title:"English"
//    },
//    {
//        title:"Nederlands"
//    },
//    {
//        title:"Türkçe"
//    },
//    {
//        title:"عـــربـــي"
//    }
// ]