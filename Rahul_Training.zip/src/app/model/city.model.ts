export class City {
    public id: number;
    public name: string;
}
